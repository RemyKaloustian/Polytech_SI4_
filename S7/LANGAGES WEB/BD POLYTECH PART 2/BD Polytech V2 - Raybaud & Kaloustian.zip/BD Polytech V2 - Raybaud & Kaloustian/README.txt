LANGAGES DU WEB - Vincent RAUBAUD & Rémy KALOUSTIAN

Pour chaque scénario, il y a un dossier idoine contenant la base en XML et sa transformation XSL.

Pour le scénario 4, la nouvelle structure XML est visible en ouvrant la fenêtre développeur (F12).

Le rapport décrit notre travail.
