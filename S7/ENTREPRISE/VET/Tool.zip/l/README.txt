Placer tout le dossier /l à la racine du site.
Me dire quand c’est bon, et voilà :D